package com.example.borabook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BookActivity extends AppCompatActivity {

    private String tag = "메인";
    Button button;
    Fragment1 fragment1; // 왼쪽 가계부 목록 화면
    Fragment2 fragment2; // 오른쪽 가계부 쓰기 화면
    BottomNavigationView bottomNavigation; // 하단 네비

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.loginBtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intnet);
            }
        });
        fragment1 = new Fragment1();
        fragment2 = new Fragment2();


    }

    public void onTabSelected(int position) {
        if(position==0) {
            bottomNavigation.setSelectedItemId(R.id.tab1);
        } else  {
            bottomNavigation.setSelectedItemId(R.id.tab2);
        }


    }
}