package com.example.borabook;

public class Detail {
    int detail_num;
    String iow;
    int money;
    String memo;

    public Detail(int detail_num, String iow, int money, String memo) {
        this.detail_num = detail_num;
        this.iow = iow;
        this.money = money;
        this.memo = memo;
    }

    public int getDetail_num() {
        return detail_num;
    }

    public void setDetail_num(int detail_num) {
        this.detail_num = detail_num;
    }

    public String getIow() {
        return iow;
    }

    public void setIow(String iow) {
        this.iow = iow;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
}
