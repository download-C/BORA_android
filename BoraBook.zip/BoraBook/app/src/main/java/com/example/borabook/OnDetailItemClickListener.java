package com.example.borabook;

import android.view.View;

public interface OnDetailItemClickListener {
    public void onItemClick(DetailAdapter.ViewHolder holder, View view, int position);
}
