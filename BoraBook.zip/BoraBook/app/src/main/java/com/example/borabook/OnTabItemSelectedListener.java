package com.example.borabook;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
}
