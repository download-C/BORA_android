package com.example.borabook;

public class BookDetail {
    String iow;
    Integer money;
    String memo;
}
